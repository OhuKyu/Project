package buoi6.observer;

public interface Subscriber {
    void update();
}
